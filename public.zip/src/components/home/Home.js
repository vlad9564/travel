import React from 'react';



import StatisticDetails from './StatisticDetails';

class Home extends React.Component {

    render() {
        return (
            <div>
                <div >
                    <StatisticDetails></StatisticDetails>
                </div>
            </div>
        )
    }

}
export default Home;