import React from 'react';

class placeToVisit extends React.Component {


    render() {
        return (
            <div>Place to visit</div>
        )
    }

}

export default placeToVisit;