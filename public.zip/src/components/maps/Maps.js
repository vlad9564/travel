import React, { Component } from 'react';
import GoogleMapReact from 'google-map-react';
import Marker from './markers';
import PopOver from './popOver';

const AnyReactComponent = ({ text }) => <div>
    {/* <ui5-icon src="sap-icon://map"></ui5-icon> */}
    <ui5-icon class="marker" src="sap-icon://map"  ></ui5-icon>

</div>;

var datas = AnyReactComponent;

class SimpleMap extends Component {
    static defaultProps = {
        center: {
            lat: 45.6524567,
            lng: 25.5264228
        },
        zoom: 11
    };

    onSetPoint(event) {
        debugger;
        // TODO: You are sure?
        alert(event.lat + ":" + event.lng);


    }

    render() {
        return (
            // Important! Always set the container height explicitly
            <div style={{ height: '100vh', width: '100%' }}>
                <GoogleMapReact
                    bootstrapURLKeys={{ key: "AIzaSyDP8-1VEYcU8haY6KHHrfL-pvnCTIq4oBk" /* YOUR KEY HERE */ }}
                    defaultCenter={this.props.center}
                    defaultZoom={this.props.zoom}
                    onClick={this.onSetPoint}>


                    <Marker ></Marker>
                    <Marker></Marker>
                    <Marker></Marker>

                </GoogleMapReact>
            </div>
        );
    }
}

export default SimpleMap;