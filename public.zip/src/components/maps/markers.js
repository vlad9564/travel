import React from 'react';
import "@ui5/webcomponents/dist/Icon";
import './maps.css'

class Markers extends React.Component {


    render() {
        return (
            <div>
                <ui5-icon class="marker" src="sap-icon://map"  ></ui5-icon>
            </div>

        )
    }
}
export default Markers;